export const qfUtils = {
	//是否身份证
	isIDCard: (idCard: string) => {
		let num = idCard.toLowerCase().match(/\w/g)
		
		if (idCard.match(/^\d{17}[\dx]$/i) && num) {
			let sum = 0
			let times = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]
			
			for (let i = 0; i < 17; i++) {
				sum += parseInt(num[i], 10) * times[i]
			}
			
			if ('10x98765432'.charAt(sum % 11) !== num[17]) {
				return false
			}
			return !!idCard.replace(/^\d{6}(\d{4})(\d{2})(\d{2}).+$/, '$1-$2-$3')
		}
		
		return false
	},
	//是否电话号码
	isPhoneNumber: (val: string) => {
		let tel = /^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/
		return tel.test(val)
	},
	//获取随机字符
	randomStr: (len = 16) => {
		const t = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnoprstuvwxyz1234567890'
		let a = t.length
		let str = ''
		
		for (let i = 0; i < len; i++) {
			str += t.charAt(Math.floor(Math.random() * a))
		}
		return str
	},
	//随机整数
	randomNum: (min: number, max: number) => {
		return Math.floor(Math.random() * (max - min + 1) + min)
	},
	//深拷贝
	deepCopy: (obj: any) => {
		return JSON.parse(JSON.stringify(obj))
	},
	//格式化距离现在已过去的时间
	formatPassTime: (startTime: number) => {
		const currentTime = Date.parse(new Date().toString())
		const time = currentTime - startTime
		const day = parseInt(String(time / (1000 * 60 * 60 * 24)))
		const hour = parseInt(String(time / (1000 * 60 * 60)))
		const min = parseInt(String(time / (1000 * 60)))
		const month = parseInt(String(day / 30))
		const year = parseInt(String(month / 12))
		if (year) return year + "年前"
		if (month) return month + "个月前"
		if (day) return day + "天前"
		if (hour) return hour + "小时前"
		if (min) return min + "分钟前"
		else return '刚刚'
	},
	isAndroid: () => {
		return /android/.test(navigator.userAgent.toLowerCase())
	},
	isIOS: () => {
		return /ios|iphone|ipad|ipod/.test(navigator.userAgent.toLowerCase())
	},
	//判断是否移动设备
	isMobile: () => {
		const agent = navigator.userAgent;
		const k = ["android", "iphone", "ipod", "ipad", "windows phone", "mqqbrowser"];
		let flag = false;
		// Windows
		if (agent.indexOf("Windows NT") < 0 || (agent.indexOf("Windows NT") >= 0 && agent.indexOf("compatible; MSIE 9.0;") >= 0)) {
			// Mac PC
			if (agent.indexOf("Windows NT") < 0 && agent.indexOf("Macintosh") < 0) {
				for (let item of k) {
					if (agent.indexOf(item) >= 0) {
						flag = true;
						break;
					}
				}
			}
		}
		return flag;
	},
	// 拨打电话
	callPhone: (phone: string) => {
		const aElement = document.createElement('a')
		aElement.setAttribute('href', `tel:${phone}`)
		document.body.appendChild(aElement)
		aElement.click()
		document.body.removeChild(aElement)
	},
	copy: (value: string, callback: (ret: boolean) => void) => {
		if (!document.queryCommandSupported('copy')) {
			callback && callback(false)
			return
		}
		const textarea = document.createElement('textarea')
		textarea.value = value
		textarea.readOnly = Boolean('readOnly')
		document.body.appendChild(textarea)
		textarea.select()
		textarea.setSelectionRange(0, value.length)
		document.execCommand('copy')
		textarea.remove()
		callback && callback(true)
	},
	//************* 缓存相关 ****************
	// 获取指定 Cookie 值
	getCookie: (k: string) => {
		const res = RegExp('(^|; )' + encodeURIComponent(k) + '=([^;]*)').exec(document.cookie)
		return res && res[2]
	},
	// 设置 Cookie 值
	setCookie(name: string, value: string, expiresDays: number, encode = false) {
		const Days = expiresDays || 10;
		const exp = new Date();
		exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000)
		const val = encode ? escape(value) : value
		document.cookie = name + '=' + val + ';domain=zhuanzhuan.com;path=/;expires=' + exp.toUTCString()
	},
	
	//************* 数字相关 ****************
	// 数字每千位加逗号
	toThousands: (num: number) => {
		return num && num.toString()
				.replace(/\d+/, function (s) {
					return s.replace(/(\d)(?=(\d{3})+$)/g, '$1,')
				})
	},
	// 将数字转换成 金钱格式
	// 比如：1000000 转换成 1.000.000
	formatNum(num: number) {
		let str = String(num);
		let newStr = "";
		let count = 0;
		for (let i = str.length - 1; i >= 0; i--) {
			if (count % 3 === 0 && count !== 0) {
				newStr = str.charAt(i) + "," + newStr;
			} else {
				newStr = str.charAt(i) + newStr;
			}
			count++;
		}
		return newStr;
	},
	//************* 字符串相关 ****************
	// 手机号码中间4位隐藏星号
	hideMobile: (mobile: string) => {
		return mobile.replace(/^(\d{3})\d{4}(\d{4})$/, "$1****$2")
	},
	//手机号格式验证
	phoneValidator: (val: string) => /^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/.test(val),
	
	//检测密码强度 1：密码弱 2：密码中等 3：密码强 4：密码很强
	checkPassWord: (str: string) => {
		let level = 0;
		if (str.length < 6) {
			return level
		}
		if (/[0-9]/.test(str)) {
			level++
		}
		if (/[a-z]/.test(str)) {
			level++
		}
		if (/[A-Z]/.test(str)) {
			level++
		}
		if (/\W/.test(str)) {
			level++
		}
		return level
	},
	// 随机产生某个颜色
	randomColor: () => {
		return `rgb(${qfUtils.randomNum(0, 255)}, ${qfUtils.randomNum(0, 255)}, ${qfUtils.randomNum(0, 255)})`
	},
	// 字符串替换全部 s0-原始字符串，s1-要替换的字符串，s2-替换成的字符串
	replaceAll: (s0: string, s1: string, s2: string) => {
		return s0.replace(new RegExp(s1, "gm"), s2);
	},
	//只显示第一个字符 汉字
	ellipsisFirst: (str: string, len: number) => {
		return str.length > len ? (len > 1 ? str.slice(0, len) + '...' : str.slice(0, len)) : str;
	},
}