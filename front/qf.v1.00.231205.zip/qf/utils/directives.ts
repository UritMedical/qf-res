export const directives = [
    {
        /**
         * 防止快速重复点击
         * 使用示例： v-preventReClick="500"
         */
        key: "preventReClick",
        command: (el: any, binding:any) => {
            function preventReClickFun(elValue: any, bindingValue: any) {
                if (!elValue.disabled) {
                    elValue.disabled = true
                    setTimeout(() => {
                        elValue.disabled = false
                    }, bindingValue.value || 1000)
                }
            }

            el.addEventListener('click', () => preventReClickFun(el, binding))
            binding.dir.unmounted = function () {
                el.removeEventListener('click', () => preventReClickFun(el, binding))
            }
        }
    }
]