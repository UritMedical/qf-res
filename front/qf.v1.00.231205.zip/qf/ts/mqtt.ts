// @ts-nocheck
import {qfUtils} from "$/utils";
import type {MessageCallback, Topic} from "$/model";

export class MqttClient {
    private mqClient: any = null
    private isConnected: boolean = false //是否连接
    private topics: Topic[] = [] //所有订阅的topic

    constructor(url: string) {
        this.connect(url)
    }

    /**
     * 连接到Broker
     * @param url `ws://${host}:${port}/[path]`
     */
    private connect(url: string) {
        if (!url) {
            console.log("url is null")
            return
        }
        console.log("connect mqtt, url = ", url)
        const options = {
            clean: true,
            connectTimeout: 10000,
            reconnectPeriod: 10 * 1000,
            clientId: qfUtils.randomStr(10),
        }
        //连接Broker
        this.mqClient = mqtt.connect(url, options)
        if (!this.mqClient) {
            console.log("connect mqtt failed")
            return;
        }
        //监听消息
        this.mqClient.on('message', (topic: string, message: any) => {
            const data = message.toString()
            // console.log("===>mqtt message", topic, data)
            this.topics.forEach((item) => {
                if (item.topic === topic) {
                    item?.callback(topic,JSON.parse(data))
                }
            })
        })

        //连接成功
        this.mqClient.on('connect', () => {
            console.log("--> mqtt connect success!")
            this.isConnected = true
            //重新订阅所有topic
            this.topics.forEach((topic) => {
                if (this.mqClient) {
                    this.mqClient.unsubscribe(topic.topic)
                    this.mqClient?.subscribe(topic.topic, {qos: topic.qos === 0 ? 0 : 1}, () => {
                    })
                }
            })
        })

        //每次掉线的时候都会触发
        this.mqClient.on('offline', () => {
            console.log("mqtt offline")
            this.isConnected = false
        })

        //每次重连时触发
        this.mqClient.on('reconnect', () => {
            console.log("mqtt reconnecting...")
        })

        //每次重连失败都会回调连接关闭
        this.mqClient.on('close', () => {
            console.log("mqtt close")
        })

        //出现错误
        this.mqClient.on('error', (error) => {
            console.log("mqtt error", error)
        })
    }

    /**
     * 订阅主题
     * @param topic
     * @param qos
     * @param cb
     */
    Subscribe<T>(topic: string, cb: MessageCallback<T>) {
        if (this.mqClient == null) {
            return
        }
        // console.log("subscribe topic", topic)
        if (this.isConnected && this.mqClient != null) {
            this.mqClient.subscribe(topic, {qos: 0}, () => {
                console.log("subscribe " + topic + " success")
            })
        }
        const t: Topic<T> = {
            topic: topic,
            qos: 0,
            callback: cb
        }
        this.topics.push(t)
    }

    /**
     * 发布消息
     * @param topic
     * @param data
     */
    Publish(topic: string, data: string) {
        if (this.mqClient == null) {
            return
        }
        this.mqClient.publish(topic, data)
        // console.log("publish topic", topic, data)
    }
}


