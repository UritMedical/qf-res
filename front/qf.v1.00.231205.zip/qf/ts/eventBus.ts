import mitt from "mitt";

export class EventBus {
    private emitter: any  //事件总线
    constructor() {
        //初始化事件总线
        this.emitter = mitt()
    }

    On(event: string, callback: any): void {
        this.emitter.on(event, callback)
    }

    Emit(event: string, data: any): void {
        this.emitter.emit(event, data)
    }

    Off(event: string, callback: any): void {
        this.emitter.off(event, callback)
    }
}