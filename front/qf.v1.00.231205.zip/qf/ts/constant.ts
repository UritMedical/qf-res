//Qf里面的常量配置
export const Constant = {
	//路径配置
	ConfigPath: "./config.json",//配置文件路径

	//前端总线事件
	EventHttpError: "EventHttpError",//Http错误的总线事件
	EventTokenReady: "EventTokenReady",//Token准备好的事件

	//LocalStorage存储Key
	KeyToken: "token",//存储Token的Key

	// //后端接口
	// ApiCheckToken: "api/check_token",//检查Token的API
	ApiConfig: "api/config" //获取配置的接口
}
