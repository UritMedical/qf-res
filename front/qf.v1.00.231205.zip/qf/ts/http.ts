import type {AxiosInstance} from "axios";
import axios from 'axios'
import type {qfHttpError} from "$/model";
import {Constant} from "$/ts/constant";
import type {EventBus} from "$/ts/eventBus";

export class Http {
    private axiosInstance: AxiosInstance
    private readonly eventBus: EventBus

    constructor(eventBus: any, rootPath: string) {
        this.eventBus = eventBus
        this.axiosInstance = axios.create({
            timeout: 10000,
        })
        if (rootPath) {
            this.axiosInstance.defaults.baseURL = rootPath
        }
        this.axiosInstance.defaults.headers['Content-Type'] = 'application/json;charset=utf-8'

        //请求拦截
        this.axiosInstance.interceptors.request.use(
            function (config) {
                config.headers.token = localStorage.getItem(Constant.KeyToken)
                return config
            },
            function (error) {
                return Promise.reject(error.response)
            },
        )

        //响应拦截
        this.axiosInstance.interceptors.response.use(
            (success) => {
                return success.data.data
            },
            (e) => {
                if (!e.response) {
                    const errInfo: qfHttpError = {
                        errCode: 600,
                        status: 600,
                        msg: e.message,
                    }
                    return Promise.reject(errInfo)
                }
                const err = e.response.data
                const errInfo: qfHttpError = {
                    errCode: err?.code || 0,
                    status: err?.status,
                    msg: err?.msg,
                }
                console.log('== onRejected response === ', errInfo)
                //把错误信息发送到前端UI，让UI决定如何处理请求异常
                this.eventBus?.Emit(Constant.EventHttpError, errInfo)
                return Promise.reject(errInfo)
            },
        )
    }

    /**
     * 发送post请求
     * @param url
     * @param data
     */
    Post<T>(url: string, data: any): Promise<T> {
        return this.axiosInstance.post(url, data);
    }

    /**
     * 发送get请求
     * @param url
     * @param params
     */
    Get<T>(url: string, params: any): Promise<T> {
        return this.axiosInstance.get(url, {params: params});
    }

    /**
     * 发送delete请求
     * @param url
     * @param params
     */
    Delete<T>(url: string, params: any): Promise<T> {
        return this.axiosInstance.delete(url, {params: params});
    }

    /**
     * 发送put请求
     *  @param url
     *  @param data
     */
    Put<T>(url: string, data: any): Promise<T> {
        return this.axiosInstance.put(url, data);
    }
}
