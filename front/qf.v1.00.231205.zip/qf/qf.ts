/**
 * @Author: tangxinglong
 * @Description: QF主要类，用于前端组件之间的通信，接口的实现
 */
import {MqttClient} from "$/ts/mqtt";
import {Http} from "$/ts/http";
import type {QfInterface} from "$/interface";
import {Constant} from "$/ts/constant";
import {qfUtils} from "$/utils";
import {EventBus} from "$/ts/eventBus";

//Qf类
class QfImpl implements QfInterface {
    config: any   //项目配置

    Mqtt: MqttClient
    EventBus: EventBus
    Request: Http

    constructor() {
        this.EventBus = new EventBus()
        //初始化Request
        this.Request = new Http("", "")
        this.Mqtt = new MqttClient("")
    }

    async StartQf(): Promise<void> {
        console.log("StartQf()")
        await this.Request?.Get<any>(Constant.ConfigPath, {}).then((res) => {
            this.config = res
        })
        console.log('config = ', this.config)
        this.Request = new Http(this.EventBus, this.config?.apiRootPath)
        //初始化MQTT
        if (this.config?.useMqtt) {
            this.Mqtt = new MqttClient(this.config.brokerUrl)
        }

        // //检测Token
        // if (this.config?.useUser) {
        //    this.checkToken()
        // }
    }

    /**
     * 检查Token是否有效
     * @private
     */
    // private checkToken() {
    //     //1、从本地获取token如果为空则直接跳转到登录页面
    //     const token = localStorage.getItem(Constant.KeyToken)
    //     if (!token) {
    //         //跳转到登录页面
    //         this.EventBus?.Emit(Constant.EventHttpError, {
    //             errCode: 0,
    //             status: 401,
    //             message: 'token is null'
    //         })
    //         return
    //     }
    //     //2、从服务端检查token是否有效
    //     this.Request?.Get(Constant.ApiCheckToken, {})
    // }

    GetAppConfig(): any {
        return qfUtils.deepCopy(this.config)
    }
}

//导出Qf接口
export const Qf = new QfImpl() as QfInterface
