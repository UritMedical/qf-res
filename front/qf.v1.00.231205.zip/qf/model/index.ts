//  MQTT消息回调
export type MessageCallback<T> = (topic: string, data: T) => void

/**
 * 前端订阅MQTT消息需要传入的参数
 */
export interface Topic<T> {
	topic: string;
	qos: number
	callback: MessageCallback<T>
}

export interface qfHttpError {
	errCode: number;
	status: number;
	msg: string;
}

