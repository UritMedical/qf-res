/**
 * @Author: tangxinglong
 * @Description: 定义了Qf的接口
 */
import type {Http} from "$/ts/http";
import {MqttClient} from "$/ts/mqtt";
import type {EventBus} from "$/ts/eventBus";

//  Qf接口
export interface QfInterface {
    /**
     * API请求
     */
    Request: Http;

    /**
     * MQTT示例
     */
    Mqtt: MqttClient;

    /**
     * 前端事件总线
     */
    EventBus: EventBus;

    /**
     * 启动QF
     */
    StartQf(): Promise<void>;

    /**
     * 获取前端的配置
     */
    GetAppConfig(): any;
}
