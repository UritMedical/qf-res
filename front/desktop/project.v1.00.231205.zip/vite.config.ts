import {fileURLToPath, URL} from 'node:url'

import {defineConfig} from 'vite'
import vue from '@vitejs/plugin-vue'

// https://vitejs.dev/config/
export default defineConfig({
	plugins: [
		vue(),
    ],
    optimizeDeps: {
        // include: ['@/libs/vform-render/render.umd.js']  //此处路径必须跟main.js中import路径完全一致！
    },
    build: {
        /* 其他build生产打包配置省略 */
        //...
        commonjsOptions: {
            include: /node_modules|lib/
        }
    },
    resolve: {
        alias: {
            '@': fileURLToPath(new URL('./src', import.meta.url)),
            '$': fileURLToPath(new URL('./qf', import.meta.url)),
        }
    },
    server: {
        host: "0.0.0.0",
        port: 8888,
        open: true,
        proxy: {
            '/api': {
                target: 'http://localhost:3333/',
                changeOrigin: true,
            }
        }
    }

})
