/// <reference types="vite/client" />
declare module 'element-plus/dist/locale/zh-cn.mjs'
declare module '@vant/auto-import-resolver'
declare module 'vue-grid-layout'