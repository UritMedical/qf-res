import type {Lang} from "@/local-model/lang";

/**
 * 默认的文本
 */
export const defaultLang: Lang = {
    bottomBar: {
        optAllSamples: "AllSamples",
        optUnAudited: "UnAudited",
        optDoubt: "Doubt",
        optRetest: "Retest",
        optAudited: "Audited",
        filterTitle: "Filter",
        sampleNo: "Sample No",
        device: "Device",
        btnAudit: "Audit",
        btnDoubt: "Doubt",
        btnRetest: "Retest",
        btnBatchAudit: "Batch Audit",
        btnFilter: "Filter",
        btnPrev: "Prev",
        btnNext: "Next",
        btnSpecialProtein: "Special Protein",
        btnConfirm: "Confirm",
        btnCancel: "Cancel"
    }
}