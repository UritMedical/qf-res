/**
 * 定义一些常量
 */
export const DictEvent = {
    // EventKeyUpDown: "EventKeyUpDown",//上下箭头按下发出的事件
    // EventCurSampleChange: "EventCurrentChange",//当前样本改变
}
