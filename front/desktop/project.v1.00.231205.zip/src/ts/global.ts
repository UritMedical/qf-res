import {reactive} from 'vue';
import type {Lang} from "@/local-model/lang";
import {Qf} from "$/qf";
import {defaultLang} from "@/ts/def-lang";

/**
 * 应用全局数据
 */
export const global = reactive({
    lang: {} as Lang,
    appConfig: {} as any, //app项目配置
})

/**
 * 初始化全局数据
 */
export const initGlobalData = () => {
    //获取配置
    global.appConfig = Qf.GetAppConfig()

    //获取语言
    global.lang = defaultLang
    // apis.common.GetLang(l).then(res => {
    //     global.lang = res
    // })
}

