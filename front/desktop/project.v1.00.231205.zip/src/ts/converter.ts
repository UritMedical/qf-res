/**
 * 定义一些Vue中显示数据、class显示用的转换器
 *
 */
export const convertor = {
    // ItemGpType: string[],//包含测试项目所属类别，如UC,UD,AU
    // gpTypeToName: (types: string[], name: string): string => {
    //     if (types && types.includes(name)) {
    //         return 'circle-fill'
    //     } else {
    //         return 'circle-line'
    //     }
    // },
}