<script setup lang="ts">
import {reactive} from "vue";
import {apis} from "@/define/api";
import type {Models} from "@/define/model";
import {global} from "../../ts/global";

const data = reactive({
    name: ''
})

const methods = {
    init() {

    },
    handleClick() {
        console.log('按钮被点击了');
        // 这里放置按钮点击后的处理逻辑
    },
    createUser() {
        const user: Models.User = {
            Id: 1,
            Name: "张三",
            Phone: '13666668888'
        }
        apis.user.CreateUser(user).then(data => {
            console.log("createUser success", data);
        })
    },
    getUser() {
        apis.user.GetUser(1).then(data => {
            console.log("getUser success ", data);
        })
    }
}

</script>

<template>
    <div style="padding: 20px">
        <!-- 1000ms 内不重复响应-->
        <el-button v-preventReClick="500" type="primary" @click="methods.handleClick">防抖按钮</el-button>
        <el-button type="primary" @click="methods.createUser">创建用户</el-button>
        <el-button type="primary" @click="methods.getUser">获取用户信息</el-button>
        <div>
            多国语言：{{global.lang.bottomBar.btnConfirm}}
        </div>
    </div>
</template>

<style scoped>
.ml-md {
    margin-left: 20px;
}
</style>