<script setup lang="ts">

import {useRouter} from "vue-router";
import {reactive} from "vue";

const router = useRouter()

const menus = [
    {name: 'Mqtt 示例', route: "/mqtt",},
    {name: 'Api 示例', route: "/api"},
]

const data = reactive({
    active: 0
})

const methods = {
    onItemClick(menu: any, index: number) {
        data.active = index
        router.push(menu.route)
    }
}

</script>

<template>
    <div class="u-row window-height">
        <div class="u-border-r" style="width: 300px">
            <div class="title text-center">
                前端框架代码示例
            </div>
            <div>
                <div class=""
                     v-for="(menu,index) in menus" :key="index">
                    <div class="menu-item el-menu u-row items-center u-pa-md"
                         :class="data.active ==index?'active':''"
                         @click="methods.onItemClick(menu,index)">
                        {{ menu.name }}
                    </div>
                </div>
            </div>
        </div>
        <div class="u-col bg-white">
            <router-view/>
        </div>
    </div>
</template>

<style scoped>

.title {
    font-size: 28px;
    padding: 50px 0;
}

.active {
    color: white;
    background-color: lightskyblue;
}
</style>