<script setup lang="ts">
import {reactive} from "vue";
import {Publisher, Subscribe} from "@/define/mqtt";

const data = reactive({
    message: '',
})

const methods = {
    init() {

    },
    subscribe() {
        //订阅topic
        Subscribe.SubscribeSampleChanged((topic, data) => {
            console.log("接收到MQTT消息", topic, data)
        })
        console.log('订阅成功')
    },
    publish() {
        Publisher.SendSampleChanged({
            Id: 11,
            Name: '张三',
            Phone: data.message
        })
        console.log('发送MQTT成功')
    }
}
</script>

<template>
    <div class="u-pa-md">
        <el-button type="primary" @click="methods.subscribe">订阅</el-button>
        <div class="u-row u-mt-md">
            <el-input style="width: 400px;"
                      v-model="data.message" label="内容" placeholder="请输入要发送的内容"/>
            <el-button class="u-ml-md" type="primary" @click="methods.publish">发送</el-button>
        </div>
    </div>
</template>

<style scoped>

</style>