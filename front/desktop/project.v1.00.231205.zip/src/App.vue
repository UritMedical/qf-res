<template>
    <RouterView></RouterView>
</template>

<script lang="ts" setup>
import {Qf} from "$/qf";
import type {qfHttpError} from "$/model";
import {useRouter} from "vue-router";
import {parseErrorCode} from "@/define/error/http";
import {initGlobalData} from "@/ts/global";
import {Constant} from "$/ts/constant";

const router = useRouter()

const methods = {
    async init() {
        //启动qf
        await Qf.StartQf()
        //加载语言
        initGlobalData()

        //注册http错误监听
        Qf.EventBus.On(Constant.EventHttpError, (e: any) => {
            const resErr: qfHttpError = e as qfHttpError
            let ret: string = parseErrorCode(resErr)
            if (ret) {
                //根据项目需要提示错误
                console.log("onHttpErrorHandler", ret)
            } else if (ret == '401') {
                console.log("no permission,go login.")
                router.push("/login")
            }
        })

        //注册TokenReady,当进入应用时，token检测完毕有效后，从后端获取用户信息
        Qf.EventBus.On(Constant.EventTokenReady, (res: any) => {
            // userStore.getUserInfo()
        })
    }
}
methods.init()

</script>