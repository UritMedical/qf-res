/**
 * 语言数据结构
 */
export interface Lang {
    bottomBar: BottomBar
}

interface BottomBar {
    // 样本状态列表
    optAllSamples: string,
    optUnAudited: string,
    optDoubt: string,
    optRetest: string,
    optAudited: string,
    filterTitle: string,
    sampleNo: string,
    device: string,
    btnAudit: string,
    btnDoubt: string,
    btnRetest: string,
    btnBatchAudit: string,
    btnFilter: string,
    btnPrev: string,
    btnNext: string
    btnSpecialProtein: string
    btnConfirm: string,
    btnCancel: string
}