import { createApp } from "vue";
import { createPinia } from "pinia";
import App from "./App.vue";

//引入动态表单
// import VFormRender from "@/libs/vform-render/render.umd.js";
// import "@/libs/vform-render/render.style.css";

//引入基础公共样式库（必须 不能删）
import "@/define/assets/css/main.scss";

//导入路由
import { router } from "@/define/router";

//ElementUI相关
import ElementPlus from "element-plus";
import "element-plus/dist/index.css";
import zhCn from "element-plus/dist/locale/zh-cn.mjs";

const app = createApp(App);
app.use(createPinia());
app.use(router);
// app.use(VFormRender)
app.use(ElementPlus, {
  locale: zhCn,
});

//指令注册
import {directives} from "$/utils/directives"
directives.forEach(item => {
  app.directive(item.key, item.command)
})

app.mount("#app");
